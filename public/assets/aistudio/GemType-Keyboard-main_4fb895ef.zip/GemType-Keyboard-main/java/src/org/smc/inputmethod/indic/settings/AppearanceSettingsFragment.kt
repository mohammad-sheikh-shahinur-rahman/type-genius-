/*
 * Copyright 2026, Jishnu Mohan <jishnu@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.smc.inputmethod.indic.settings

import android.os.Bundle

import com.android.inputmethod.latin.R
import com.android.inputmethod.latin.common.Constants
import com.android.inputmethod.latin.define.ProductionFlags

/** "Appearance" settings sub screen. */
class AppearanceSettingsFragment : SubScreenFragment() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        super.onCreatePreferences(savedInstanceState, rootKey)
        addPreferencesFromResource(R.xml.prefs_screen_appearance)
        if (!ProductionFlags.IS_SPLIT_KEYBOARD_SUPPORTED ||
            Constants.isPhone(Settings.readScreenMetrics(resources))
        ) {
            removePreference(Settings.PREF_ENABLE_SPLIT_KEYBOARD)
        }
    }

    override fun onResume() {
        super.onResume()
        ThemeSettingsFragment.updateKeyboardThemeSummary(requirePreference(Settings.SCREEN_THEME))
    }
}
